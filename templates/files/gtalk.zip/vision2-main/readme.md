여기 예제들은 openai 1.1.1 이상 버전에서 작동함

현재 버전 확인 pip show openai

openai  업그래이드 
pip install --upgrade openai
