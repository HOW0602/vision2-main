from flask import Flask, request, abort, render_template, send_from_directory, jsonify, session
import dongsooAI as ds
from langchain.document_loaders import TextLoader
app = Flask(__name__)
app.secret_key = 'GTalkStory'
# loader = WebBaseLoader(web_path="https://jeju-s.jje.hs.kr/jeju-s/0102/history")
chat_story=TextLoader("data\story.txt", encoding='utf-8').load()[0].page_content
# print( chat_story)

@app.route('/')
def hello():
    ret="""
    <h1 style="margin:40px; border: 1px solid green; border-radius:4px ; padding:50px">
        <a href="https://127.0.0.1:5001/gptalk.html" style="text-decoration: none;">
        마이크와 스피커를 이용한 대화 챗봇 지톡(GTalk)
        </a>
    </h1>
     <h1 style="margin:40px; border: 1px solid green; border-radius:4px ; padding:50px">
        <a href="https://127.0.0.1:5001/dalle.html" style="text-decoration: none;">
        dalle-3 택스트로 이미지를 그리다. (GTalk)
        </a>
     </h1>
      <h1 style="margin:40px; border: 1px solid green; border-radius:4px ; padding:50px">
        <a href="https://127.0.0.1:5001/vision1.html" style="text-decoration: none;">
        vision-1 인터넷 url 이미지 분석 
        </a>
     </h1>
      <h1 style="margin:40px; border: 1px solid green; border-radius:4px ; padding:50px">
        <a href="https://127.0.0.1:5001/vision2.html" style="text-decoration: none;">
         vision-2 파일 또는 인터넷 주소  이미지  분석
        </a>
     </h1>
    """
    return ret
@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory('templates/files', filename, as_attachment=True)

@app.route('/audio/<filename>') 
def audio(filename):
    return send_from_directory("templates/audio", filename)

@app.route('/images/<filename>') 
def images(filename):
    return send_from_directory("templates/images", filename)
@app.route('/chat_audio/<filename>') 
def chat_audio(filename):
    return send_from_directory("templates/chat_audio", filename)

@app.route('/<page>')
def page(page):
    if 'token' not in session:
        session['token'] = ds.rnd_str(n=20, type="s")
    if ".html" in page:
       return render_template(page, token=session['token'])
    else:
       return send_from_directory("templates", page)
   

@app.route("/vision", methods=["POST"])
def vision():
    prompt = request.json.get("prompt")
    image_infor = request.json.get("image_infor") 
    print( "vision prompt=", prompt )
    print( "image_infor=", image_infor[:50] )
    re=ds.vision_talk(prompt=prompt,image_infor=image_infor)

    
    print( re )
    
    return jsonify(re)

@app.route("/dalle3", methods=["POST"])
def dalle3():
    prompt = request.json.get("prompt")
    print("dalle3 prompt=",prompt)
    re=ds.image_create(prompt=prompt)
    print(re ) 
    return jsonify(re)

@app.route("/chatGPT_tts", methods=["POST"])
def chatGPT_tts():
    prompt= request.json.get("prompt")
    voice= request.json.get("voice")
    chat_id=request.json.get("chat_id")
    print("prompt= ", prompt)
    global chat_story
    re=ds.chatGPT_tts(query=prompt,voice=voice,chat_id=chat_id,chat_story=chat_story,token=session['token'])
    return jsonify(re)


# if __name__ == '__main__':
#     app.run(debug=True, host="0.0.0.0", port=5001)
if __name__ == '__main__':
    app.run(ssl_context=('openSSL/cert.pem', 'openSSL/key.pem'),debug=True,  port=5001)    
